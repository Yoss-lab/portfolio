I am BEGGING you to make a portfolio. It's the first thing editors and hiring managers are going to look at. It's part of how they vet freelancers. 

Your portfolio needs to include the following:
• A little about you
• Your best work 
• Your services
• Your contact information
• Testimonials

I made mine with WordPress many years ago. I share this link with anyone I want to work with: https://lnkd.in/gwVXr_Cy When you Google me (and editors will Google you!) it's the first thing you see.

I know that the particulars of setting up a portfolio for the first time are overwhelming. Where do you host? How do you set up a website? There are a lot of options out there, but most important is having a portfolio that's easy to manage and update.

If you're a writer, I suggest setting up a profile on Skyword and Contently in addition to having a portfolio.

I recently wrote about why you should have a portfolio for Contra. The team just launched portfolio templates crafted specifically for independents! https://lnkd.in/gcsrXX6f

So if you haven't yet built your portfolio, please make it a priority. I'm already seeing brands looking for freelancers for 2023 work — and you better believe they'll want to see your portfolio.

Questions? Ask me anything in the comments:



#wordpress #freelancers #google #writer #portfoliowebsite #portfolio #freelancelife #freelancewriter #freelance #writingtips #writingcommunity #writingtips 