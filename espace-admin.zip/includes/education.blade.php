<section class="educations">
    <div class="container">
        <div class="section-title">My educations</div>
        <div class="items-view">
            <div class="item education">
                <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                <div class="cnt">
                    <div class="item-title">Bachelor of Computer Sciences</div>
                    <div class="item-desc"> desc
                        <span><i class="fa fa-calendar"></i>2016 - 2017</span>
                    </div>
                </div>
                
                
            </div>
            <div class="item education">
                <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                <div class="cnt">
                    <div class="item-title">Licence of Computer Sciences</div>
                    <div class="item-desc"> desc
                        <span><i class="fa fa-calendar"></i>2017 - 2020</span>
                    </div>
                </div>
                
                
            </div>
          
            
            
        </div>
    </div>
</section>