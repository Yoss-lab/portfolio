<section class="works">
    <div class="container">
        <div class="section-title">Educations & Works</div>
        <div class="swiper">
            
                <div class="items-view swiper-wrapper">
                <div class="swiper-slide">
                        <div class="item work">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Bachelor of Computer Sciences</div>
                                <div class="item-desc"> desc
                                    <span><i class="fa fa-calendar"></i>2016 - 2017</span>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item work ">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Licence of Computer Sciences</div>
                                <div class="item-desc"> desc
                                    <span><i class="fa fa-calendar"></i>2017 - 2020</span>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item work">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Stage projet fin d'étude <span>LEONI</span></div>
                                <div class="item-desc"> 
                                    <span><i class="fa fa-calendar"></i>04/2020 - 07/2020</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item work">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Stage d'été <span>Tunisie Computer Services</span></div>
                                <div class="item-desc"> 
                           
                                    <span><i class="fa fa-calendar"></i>02/2021 - 03/2021</span>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item work">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Informaticienne <span>Centre L'Excellence Privée de Formation<span></div>
                                <div class="item-desc"> Formatrice informatique </br>
                                
                                
                                    <span><i class="fa fa-calendar"></i>03/2021 - 09/2021</span>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="item work slide-card">
                            <!-- <div class="tool-image"><img src="img/VScode.png"></div> -->
                            <div class="cnt">
                                <div class="item-title">Développeur web full-stack <span>Webspirit</span></div>
                                <div class="item-desc"> 
                                
                                    <span><i class="fa fa-calendar"></i>09/2021 - Présent</span>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                </div>
            <div class="swiper-btn">
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            </div>
           
        </div>
    </div>

</section>
