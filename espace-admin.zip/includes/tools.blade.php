<section class="tools">
    <div class="container">
        <div class="section-title">Tools & TECH</div>
        <div class="items-view">
            <div class="item tool">
                <div class="item-image"><img src="img/VScode.png"></div>
                <div class="cnt">
                    <div class="item-title">VS code</div>
                    <div class="item-desc"></div>
                </div>
                
                
            </div>
            <div class="item tool">
                <div class="item-image"><img src="img/github.png"></div>
                <div class="cnt">
                    <div class="item-title">GitHub</div>
                    <div class="item-desc"></div>
                </div>
            </div>
            <div class="item tool">
                <div class="item-image"><img src="img/laragon.png"></div>
                <div class="cnt">
                    <div class="item-title">Laragon</div>
                    <div class="item-desc"></div>
                </div>
            </div>
            <div class="item tool">
                <div class="item-image"><img src="img/WampServer.png"></div>
                <div class="cnt">
                    <div class="item-title">Wampx</div>
                    <div class="item-desc"></div>
                </div>
            </div>
            <div class="item tool">
                <div class="item-image"><img src="img/FileZilla.png"></div>
                <div class="cnt">
                    <div class="item-title">FileZilla</div>
                    <div class="item-desc"></div>
                </div>
            </div>
            <div class="item tool">
                <div class="item-image"><img src="img/AdobePhotoshop.png"></div>
                <div class="cnt">
                <div class="item-title">Adobe photoshop</div>
                <div class="item-desc"></div>
                </div>
                
            </div>
            
            <div class="item tool">
                <div class="item-image"><img src="img/studio.webp"></div>
                <div class="cnt">
                <div class="item-title">Android Studio</div>
                <div class="item-desc"></div>
                </div>
                
            </div>
            
            
        </div>
    </div>
</section>