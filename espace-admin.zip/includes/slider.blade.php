<section id="slider" class="slider d-flex align-items-center">
    <div class="cnt">
        <!-- <div class="bg-icon-slider">
            <div id="icon-slider" class="icon-slider"></div>
        </div> -->
        <!-- <div class="slogan-slider handwritten text-3xl cursor-pointer">Yosra Hassani</div> -->

        <h1 class="title-slider">Hi, I'm Yosra!</h1>
        <h2 class="sub-title-slider">I am a web developer</h2> 
        <div class="text-slider">Good level experience in web design and development knowledge, producing quality work.</div>
        <!-- <a href="#about" class="btn-get-started scrollto">
            <i class="bi bi-chevron-double-down"></i>
        </a> -->
    </div>
</section>