<section class="achievement">
    <div class="about__info">
        <div class="item-about">
        <span class="about__info-title">01+</span>
        <span class="about__info-name">Years <br>
            experience</span>
        </div>
        <div class="item-about">
        <span class="about__info-title">2+</span>
        <span class="about__info-name">Completed <br>
            project</span>
        </div>
        <div class="item-about">
        <span class="about__info-title">05+</span>
            <span class="about__info-name">Companies <br> worked</span> 
        </div>
    </div>
</section>