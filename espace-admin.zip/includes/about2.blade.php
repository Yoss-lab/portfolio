<div id="about" class="about justify-content-center align-items-center m-auto">
    <div class="container d-flex flex-md-row-reverse flex-column justify-content-center align-items-center m-auto">

        <div class="about-box  text-left col-md-6">
            <!-- <div class="about-image"><img src="img/about-img2.webp" alt="Autohr Image"></div> -->
            <!-- <ul class="social-icons">
                <li><a href="#"><i class="fa fa-facebook"></i></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul> -->
            <h4 class="author-name"><b class="light-color">Full-stack Web Developer ,</b></h4>
            <div class="cnt-text">
                <p class="width-trait">
                with good knowlegde and one year of experience, working in Front-end web technologies and delivering quality work.</p>

                <p>I am passionate about improving my coding skills & developing applications & websites.</p>
                
                <p>In addition, I working width Laravel web back-end framework.</p>
                <p>I’m currently learning more about ReactJS.</p>
                <p>Working for myself to improve my skills.</p>
            </div>
           
            <!--  <div class="signature-image"><img src="img/signature-image.png.webp" alt="Signature Image"></div>-->            <a class="more-link" href="#"><b>READ MORE</b></a>
        </div>

        <div class="col-md-6">
            <div class="about-image">
                <img src="img/profile.jpeg">
            </div>
        </div>
    </div>
   
</div>