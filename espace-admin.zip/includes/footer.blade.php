<footer class="footer row m-auto align-items-center justify-content-center">

    <div class="contact col-sm-8 row m-auto align-items-center justify-content-center">
        <div class="container row m-auto align-items-center justify-content-center">

            <div class="item-footer col-sm-6 row m-auto align-items-center justify-content-center">
                <div class="section-title">Something in mind Lets talk</div>
                <ul class="social-icons">
                    <li><a href="#"><i class="fa fa-envelope"></i></i></a></li>
                    <li><a href="#"><i class="fa fa-phone"></i></a></li>
                </ul>
            </div>
            <div class="item-footer col-sm-6 row m-auto align-items-center justify-content-center">
                <div class="section-title">Find me on</div>
                <ul class="social-icons">
                    <li><a href="#"><i class="fa fa-github"></i></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="copyright col-sm-4 row m-auto align-items-center justify-content-center">
        <div class="container">

            <div class="section-title">Copyright © 2022 Yosra Hassani</div>
        </div>
    </div>

</footer>