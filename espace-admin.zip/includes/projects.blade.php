<section class="projects">
    <div class="container">
        <div class="section-title">Projects</div>
        <div class="items-view">
            <div class="item skill">
                <div class="item-image"><img src="img/project1.png"></div>
                <div class="item-btn-soon"><a href="#">SOON</a></div>
                <div class="cnt">
                    <div class="item-title">titre</div>
                    <div class="item-desc">desc</div>
                    <div class="item-btn"><a href="#">GitHub</a></div>
                    
                </div>
            </div>
        
         
            <div class="item skill">
                <div class="item-image"><img src="img/project1.png"></div>
                <div class="cnt">
                    <div class="item-title">titre</div>
                    <div class="item-desc">desc</div>
                    <div class="item-btn"><a href="#">GitHub</a></div>
                    <!-- <div class="item-btn-soon"><a href="#">SOON</a></div> -->
                </div>
            </div>
        
         
            <div class="item skill">
                <div class="item-image"><img src="img/project1.png"></div>
                <div class="item-btn-soon"><a href="#">SOON</a></div>
                <div class="cnt">
                    <div class="item-title">titre</div>
                    <div class="item-desc">desc</div>
                    <div class="item-btn"><a href="#">GitHub</a></div>
                    
                </div>
            </div>
        
            
        </div>


    </div>
</section>