<section class="contact">
    <div class="container">
        <div class="section-title">Something in mind Lets talk</div>
        <ul class="social-icons">
            <li><a href="#"><i class="fa fa-envelope"></i></i></a></li>
            <li><a href="#"><i class="fa fa-phone"></i></a></li>
        </ul>

        <div class="section-title">Find me on</div>
        <ul class="social-icons">
            <li><a href="#"><i class="fa fa-github"></i></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
        </ul>
            
      


    </div>
</section>