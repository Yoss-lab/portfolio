<section class="skills">
    <div class="container">
        <div class="section-title">skills & TECH</div>
        <div class="items-view">
            <div class="item skill">
                <div class="item-image"><img src="img/laravel.png"></div>
                <div class="cnt">
                <div class="item-title">Laravel</div>
                <div class="item-desc"></div>
                </div>
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/PHP.png"></div>
                <div class="cnt">
                <div class="item-title">PHP</div>
                
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/JavaScript.png"></div>
                <div class="cnt">
                <div class="item-title">JavaScript</div>
                
                </div>
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/sass.png"></div>
                <div class="cnt">
                <div class="item-title">Sass</div>
                
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/html2.png"></div>
                <div class="cnt">
                <div class="item-title">HTML</div>
                
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/bootstrap.png"></div>
                <div class="cnt">
                <div class="item-title">Bootstrap</div>
                
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src=""></div>
                <div class="cnt">
                <div class="item-title">SQL</div>
                
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src="img/WordPress.png"></div>
                <div class="cnt">
                <div class="item-title">WordPress</div>
                
                </div>
                
            </div>
            
            <div class="item skill">
                <div class="item-image"><img src="img/LaTeX.png"></div>
                <div class="cnt">
                <div class="item-title">LaTeX</div>
                </div>
                
            </div>
            <div class="item skill">
                <div class="item-image"><img src=""></div>
                <div class="cnt">
                <div class="item-title">Beamer</div>
                </div>
                
            </div>
            
        </div>
    </div>
</section>