<section class="certif">
    <div class="container">
        <div class="section-title">My certifications</div>
        <div class="items-view">
            <div class="item education">
                <div class="tool-image"><img src=""></div>
                <div class="cnt">
                    <div class="item-title">certification of ....</div>
                    <div class="item-desc"> desc
                        <span><i class="fa fa-calendar"></i>26/11/20222</span>
                    </div>
                </div>
                
                
            </div>
            <div class="item education">
                <div class="tool-image"><img src=""></div>
                <div class="cnt">
                    <div class="item-title">certification of ....</div>
                    <div class="item-desc"> desc
                        <span><i class="fa fa-calendar"></i>26/11/2022</span>
                    </div>
                </div>
                
                
            </div>
          
            
            
        </div>
    </div>
</section>